Thanks for downloading this template!

Template Name: MyResume
Template URL: https://bootstrapmade.com/free-html-bootstrap-template-my-resume/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
