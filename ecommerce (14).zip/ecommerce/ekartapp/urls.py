from ekartapp import views
from django.urls import path

urlpatterns = [
    path('',views.index,name="index"),
    path('about/',views.about,name="about"),
    path('contact/',views.contact,name="contact"),
    path('checkout/',views.checkout,name="checkout"),
    path('profile',views.profile,name="profile"),
    path('search',views.search,name="search"),
    path('cancelorder/<id>', views.cancelorder, name="cancelorder"),

]
