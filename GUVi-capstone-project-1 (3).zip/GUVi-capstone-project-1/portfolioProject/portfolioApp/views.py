from django.shortcuts import render,redirect
from django.contrib import messages
from django.contrib.auth.models import User

# Create your views here.
def index(request):
    return render(request,"index.html")


def about(request):
    return render(request,"about.html")


def contact(request):
    return render(request,"contact.html")


def blog(request):
    return render(request,"blog.html")


def handlelogin(request):
    return render(request,"login.html")


def signup(request):
    if request.method=="POST":
        fname=request.POST.get('fname')
        lname=request.POST.get('lname')
        email=request.POST.get('email')
        pass1=request.POST.get('pass1')
        pass2=request.POST.get('pass2')
        print(fname,lname,email,pass1,pass2)
        user=User.objects.create_user(email,email,pass1)
        user.first_name=fname
        user.last_name=lname
        user.save()
        # messages.info(request,f'{fname},{lname},{email},{pass1},{pass2}')
        messages.success(request,"Signup Success")
        return redirect("/login")

    return render(request,"signup.html")


