from django.urls import path
from guviapp import views

urlpatterns = [
    path('',views.index,name="index")
]