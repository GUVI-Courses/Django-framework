from django.shortcuts import render
from .models import Product
from math import ceil
# Create your views here.
def index(request):
    allProds=[]
    catprods=Product.objects.values('category','id')
    cats={item['category'] for item in catprods}
    print(cats)
    for cat in cats:
        prod=Product.objects.filter(category=cat)
        n=len(prod)
        nSlides=n//4 + ceil((n/4)-(n//4))
        print(nSlides)
        allProds.append([prod,range(1,nSlides),nSlides])
    
    print(allProds)
    params={"allProds":allProds}
    return render(request,'index.html',params)

def about(request):
    return render(request,'about.html')

def contact(request):
    return render(request,'contact.html')

def checkout(request):
    return render(request,'checkout.html')


