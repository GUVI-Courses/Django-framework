MID="add you mid"
MK="add your mk"