from django.contrib import admin
from guviapp.models import Register
# Register your models here.
admin.site.register(Register)